import requests
import json
import boto3
import configKeys as cK

api_key = "ee2e2a89c40d1b6677f969551445c8ab"
lat = "40.760780"
lon = "-111.891045"
url = "https://api.openweathermap.org/data/2.5/onecall?lat=%s&lon=%s&appid=%s&units=imperial" % (lat, lon, api_key)

response = requests.get(url)
data = json.loads(response.text)
#print(data)


current = data["current"]["temp"]
#Ftemp = (current *(9/5)) + 32
#hourly = data["hourly"]
#out_filename = "current temp"

s3_rss = boto3.resource('s3', aws_access_key_id= cK.myConfig["myAccessKeyID"],aws_secret_access_key = cK.myConfig["secretAccessKey"])

 # Download the existing stocks.csv file.
s3_rss.meta.client.download_file('tempcs3505','tempOutput.csv','/tempOutput.csv')

f = open('tempOutput.csv', "a")

#f.write("current temp\n")

f.write(str(current) + "\n")

f.close()

s3_rss.meta.client.upload_file('/tempOutput.csv', 'tempcs3505', 'tempOutput.csv')

print(current)

