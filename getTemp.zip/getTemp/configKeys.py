myConfig = {
    "myAccessKeyID" : "AKIA4DHGLSPLNQZM7V4V",
    "secretAccessKey" : "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"
    }


